#' @title Plot simple para periodo.
#' @description Hace un plot individual para un periodo en version simple para el actograma
#' @param gdata datos que saca el check.acvfilter
#' @param pct.y Factor de multiplicacion para el eje y
#' @param limites Vector de limites para el eje x
#' @param lw Numeric de weight para las bandas del grafico
#' @param set Settings file
#' @return plot de un periodo
#' @export
#' @examples
#' # setwd("D:/OneDrive/INTA/Actigrafia/testfolder")
#' # awdfile <- "2086-309-362 AJF Visit2"
#' # acveditRDS <- check.acvfilter(awdfile, set)
#' # acveditRDS <- acveditRDS$semiper
#' # names(acveditRDS)
#' # gdata <- acveditRDS[["per01"]]
#' # create.plotSimple(gdata, set = set)
#' @importFrom grDevices rgb
#' @import graphics

## ------------------------------------------------------------------------------- #
## ----- Plot para cada periodo -------------------------------------------------- #
## ------------------------------------------------------------------------------- #
# Toma un data.frame de la lista "semiper" y con eso hace el grafico
# pct.y = 1; limites = NULL; lw = 1

create.plotSimple <- function(gdata, pct.y = 1, limites = NULL, lw = 1, set = NULL){
    # nulos de paquete
    st.edit <- fin <- ini <- NULL

    # ---- Data para los ejes ----------------------------------------------------
    # X: Escala y etiquetas
    xscale <- seq(as.numeric(set$ininoc)/3600, length.out = 25)
    xlabel <- ifelse(xscale >= 48, xscale - 48,
                     ifelse(xscale >= 24, xscale - 24,
                            xscale))

    # Y: Lineas al inicio, dia, y fin
    ylinea <- as.numeric(c(set$ininoc,
                           set$inidia + hours(24),
                           set$ininoc + hours(24)))/3600

    # Y: Limites  1100 porque si no mas
    if (max(gdata$act.edit) > 0){
        chy <- (ceiling(max(gdata$act.edit)/10)*10) * pct.y
        limY <-  c(0, chy)
    } else {
        limY <- c(0, 1100)
    }

    # Limite en X
    if (class(limites) == "NULL"){
        limX <- c(min(xscale), max(xscale))
    } else {
        limX <- limites
    }


    # --- sleep y wake data para el background (indices) ---------------------------
    sdata <- find.segment(gdata, st.edit, "S")
    wdata <- find.segment(gdata, st.edit, "W")

    # Solucion por si no hay nada de sueno o vigilia
    # (agrega 1 epoch falso al final) quitando un epoch al que tiene datos
    if (nrow(wdata) == 0){statusW <- FALSE} else {statusW <- TRUE}
    if (nrow(sdata) == 0){statusS <- FALSE} else {statusS <- TRUE}

    if (statusW == FALSE){    # No hay vigilia, solo sueno
        wdata[1,"ini"] <- sdata[nrow(sdata), "fin"]
        wdata[1,"fin"] <- sdata[nrow(sdata), "fin"]
        sdata[nrow(sdata), "fin"] <- sdata[nrow(sdata), 2] - 1
    }
    if (statusS == FALSE){    # No hay sueno, solo vigilia
        sdata[1,"ini"] <- wdata[nrow(wdata), "fin"]
        sdata[1,"fin"] <- wdata[nrow(wdata), "fin"]
        wdata[nrow(wdata), "fin"] <- wdata[nrow(wdata), "fin"] - 1
    }

    # Queda un gap entre sueno y viglia porque queda 1 minuto (intervalo) blanco
    # se agrega un minuto al final
    n <- nrow(gdata)
    sdata <- mutate(sdata, fin = fin + 1)
    wdata <- mutate(wdata, fin = fin + 1)

    # Dada la correccion se excede el ultimo intervalo en S o W
    if (sdata$fin[nrow(sdata)] == (n + 1)){
        sdata$fin[nrow(sdata)] <- nrow(gdata)
    } else if (wdata$fin[nrow(wdata)] == (n + 1)){
        wdata$fin[nrow(wdata)] <- nrow(gdata)
    } else {
        stop("Error en la correccion intervalos adyacentes")
    }

    # Sueno y wake data para el background (valores)
    sdata <- mutate(sdata, ini = gdata$xscale[ini], fin = gdata$xscale[fin])
    wdata <- mutate(wdata, ini = gdata$xscale[ini], fin = gdata$xscale[fin])


    # ---- Filtros y ediciones -----------------------------------------------------
    # El filtro que retira semi.periodos completos
    fdata <- find.segment(gdata, filter, 1)
    if (nrow(fdata) > 0){
        fdata <- mutate(fdata, ini = gdata$xscale[ini], fin = gdata$xscale[fin])
    }

    # Filtro para wake to sleep = 2
    f2sleep <- find.segment(gdata, filter, 2)
    if (nrow(f2sleep) > 0){
        f2sleep <- mutate(f2sleep, ini = gdata$xscale[ini], fin = gdata$xscale[fin])
    }

    # Filtro para sleep to wake = 3
    f2wake <- find.segment(gdata, filter, 3)
    if (nrow(f2wake) > 0){
        f2wake <- mutate(f2wake, ini = gdata$xscale[ini], fin = gdata$xscale[fin])
    }


    # ----- Grafico ----------------------------------------------------------------
    # Los colores para ponerlos con alpha en rgb
    # <<col2rgb("skyblue3", alpha = 0.5)/255>>

    # Plot en blanco con Margenes nulos
    par(mar=c(2,2,0,2) + 0.5, xaxs = 'i', yaxs = 'i')
    plot(gdata$xscale, gdata$act.edit, type='n', ylab='', axes=FALSE,
         xlim=limX, ylim=limY)

    # <<SLEEP>>: Los indicadores de sueno  <<col2rgb("skyblue3", alpha = 0.5)/255>>
    for (i in 1:nrow(sdata)){
        rect(sdata$ini[i], 0, sdata$fin[i], limY[2],
             col = rgb(0.4235,0.6510,0.8039,0.5), border = "skyblue3")
    }

    # <<WAKE>>: Los indicadores de vigilia <<col2rgb("gold2", alpha = 0.5)/255>>
    for (i in 1:nrow(wdata)){
        rect(wdata$ini[i], 0, wdata$fin[i], limY[2],
             col = rgb(0.9333,0.7882,0.0000,0.5), border = "gold2")
    }

    # FILTRO: indicadores para el filtro de dia o noche completo
    if (nrow(fdata) > 0){
        for (i in 1:nrow(fdata)){
            rect(fdata$ini[i], 0, fdata$fin[i], limY[2],
                 col = rgb(1, 0, 0, 0.5), border = "red")
        }
    }

    # Modificar actividad --- Muestra las modifiaciones desde sueno a vigilia
    if (nrow(f2wake) > 0){
        for (i in 1:nrow(f2wake)){
            rect(f2wake$ini[i], limY[2] - 30, f2wake$fin[i], limY[2],
                 col = "red", border = "red")
        }
    }

    # Edita periodo --- Muestral los modificaciones desde vigilia a sueno
    if (nrow(f2sleep) > 0){
        for (i in 1:nrow(f2sleep)){
            rect(f2sleep$ini[i], 0, f2sleep$fin[i], limY[2],
                 col = rgb(0.85, 0.44, 0.84, 0.5), border = "orchid")
        }
    }

    # Anadir grafico nuevo encima
    par(new=TRUE)
    plot(gdata$xscale, gdata$act.edit, type='h', lwd = lw, col='grey20',
         ylab='', axes=FALSE, xlim=limX, ylim=limY)

    # Agrega mas detalles
    abline(v = ylinea, col = "red")
    title(ylab = (format(date(gdata$time[1]), "%A %d, %m--%Y")), line = 0.5)
    axis(side = 1, at = xscale, labels = xlabel)
    box()

    # Etiqueta en Y
    mtext(format(date(gdata$time[nrow(gdata)]), "%A %d, %m--%Y"),
          side = 4, line = 0.5)
}
